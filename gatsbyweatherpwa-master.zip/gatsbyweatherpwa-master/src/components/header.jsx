import React from "react"

export default props => <h1>{props.headerText}</h1>